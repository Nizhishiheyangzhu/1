---
name: 👩‍💻👨‍💻 Feature Request
about: Any new cool features you have in mind go here
title: ''
labels: 'feature'
assignees: ''

---


**Describe the uses of this feature**

<!-- A clear and concise description of what you want to happen. -->

**Does your feature request solve any on going issue? Please describe.**


**Additional context**

<!--Add any other context or screenshots about the feature request here.-->
